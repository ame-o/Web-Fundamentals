function remove(element) {
    element.remove();
}

// addEventListener("mouseover",function over(succulents))
// {
//     var succsdos = document.querySelector('succsdos')
// succsdos.target.querySelector('succsdos')
// }

// var succsuno = document.querySelector('succsuno')
// function out(succulents) {
//     succsuno.querySelector(imgStay);
//     console.log(onmouseover.imgStay);
// }

