function remove(element) {
    element.remove();
}

addEventListener("mouseover",function over(element))
{
    var succsdos = document.querySelector('succsdos')
element.target.querySelector('succsdos')
}

var succsuno = document.querySelector('succsuno')
function out(element) {
    element.querySelector(imgStay);
    console.log(onmouseover.imgStay);
}

